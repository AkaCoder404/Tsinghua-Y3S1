/**
 * 如果需要修改为正常上线模式，请注释下面mock的import代码
 * **/
import "@/mock/index"

 // 请在下方实现自己的后端通信函数