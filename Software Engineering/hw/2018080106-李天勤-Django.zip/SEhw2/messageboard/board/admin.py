from django.contrib import admin
import sys
from .models import User, Message

# Register models
# admin.site.register(User)
# admin.site.register(Message)